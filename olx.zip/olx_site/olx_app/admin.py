from django.contrib import admin
from olx_app.models import RequestAnalysis, ScrapyGrabDate
# Register your models here.

admin.site.register(RequestAnalysis)
admin.site.register(ScrapyGrabDate)