from django.apps import AppConfig


class OlxAppConfig(AppConfig):
    name = 'olx_app'
