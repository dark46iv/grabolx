from django.contrib import admin
from olx_app.models import RequestAnalysis
# Register your models here.

admin.site.register(RequestAnalysis)